<!--

<h1><?php echo lang('forgot_password_heading');?></h1>
<p><?php echo sprintf(lang('forgot_password_subheading'), $identity_label);?></p>

<div id="infoMessage"><?php echo $message;?></div>

<?php echo form_open("auth/forgot_password");?>

      <p>
      	<label for="identity"><?php echo (($type=='email') ? sprintf(lang('forgot_password_email_label'), $identity_label) : sprintf(lang('forgot_password_identity_label'), $identity_label));?></label> <br />
      	<?php echo form_input($identity);?>
      </p>

      <p><?php echo form_submit('submit', lang('forgot_password_submit_btn'));?></p>

<?php echo form_close();?>





-->





<?php  $this->load->view('_resources/_header')?>

<div class="page">
      <div class="page-single">
        <div class="container">
          <div class="row">
            <div class="col col-login mx-auto">
              <div class="text-center mb-6">
                <img src="../assets/dashboard/brand/UPAOlogin.png" class="h-9" alt="">
                  
                  
              </div>
                
                
              <form class="card" action="<?php echo base_url('/auth/forgot_password');?>"  method="post">
                <div class="card-body p-6">
                  <div class="card-title"><?php echo lang('Auth.forgot_password_heading');?></div>
                  <p class="text-muted"><?php echo sprintf(lang('Auth.forgot_password_subheading'), $identity_label);?></p>
                    <div id="infoMessage"><?php echo $message;?></div>
                  <div class="form-group">
                      
                      
                    <label class="form-label" for="identity">Email address</label>
                    <input type="email" class="form-control" id="identity" aria-describedby="emailHelp" placeholder="Enter email" name="identity" >
                      
                      
                  </div>
                  <div class="form-footer">
                    <button type="submit" class="btn btn-primary btn-block">Enviar link</button>
                  </div>
                </div>
              </form>
              <div class="text-center text-muted">
                Forget it, <a href="<?php echo base_url();?>">send me back</a> to the sign in screen.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>






<?php  $this->load->view('_resources/_footer')?>
